#include "Parameter.h"

void Parameter::setString(string input)
{
    parameter = input;
}

string Parameter::getVal()
{
    return parameter;
}
/*type Parameter::getType()
{
    return paraType;
}*/