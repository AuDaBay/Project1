#include "Header.h"
using namespace std;

void Header::addColumn(string str)
{
    attributes.push_back(str);
}