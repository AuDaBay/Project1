#ifndef PROJECT1_HEADER_H
#define PROJECT1_HEADER_H
#include <vector>
#include <string>
using namespace std;

class Header {

public:
    vector<string> attributes;
    void addColumn(string str);
};


#endif //PROJECT1_HEADER_H
